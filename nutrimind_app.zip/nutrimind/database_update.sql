-- ============================================
-- NutriMind - Script de Atualização do Banco
-- Executar no PostgreSQL antes de usar o sistema
-- ============================================

-- 1. Tabela de Usuários
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    email VARCHAR(200) NOT NULL UNIQUE,
    password VARCHAR(200) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'NUTRITIONIST',
    active BOOLEAN NOT NULL DEFAULT TRUE
);

-- 2. Tabela de Nutricionistas
CREATE TABLE IF NOT EXISTS nutritionists (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    crn VARCHAR(50) NOT NULL,
    CONSTRAINT fk_nutritionist_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE
);

-- 3. Tabela de Pacientes (verificação)
CREATE TABLE IF NOT EXISTS patients (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    birth_date DATE,
    cpf VARCHAR(14) NOT NULL,
    email VARCHAR(200),
    phone VARCHAR(20),
    active BOOLEAN NOT NULL DEFAULT TRUE
);

-- 4. Tabela de Consultas (verificação)
CREATE TABLE IF NOT EXISTS consultation (
    id SERIAL PRIMARY KEY,
    patient_id INTEGER NOT NULL,
    nutritionist_id INTEGER NOT NULL,
    date VARCHAR(20),
    notes TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    CONSTRAINT fk_consultation_patient
        FOREIGN KEY (patient_id) REFERENCES patients(id)
        ON DELETE CASCADE,
    CONSTRAINT fk_consultation_nutritionist
        FOREIGN KEY (nutritionist_id) REFERENCES nutritionists(id)
        ON DELETE CASCADE
);

-- 5. Tabela de Avaliações Nutricionais (NOVA)
CREATE TABLE IF NOT EXISTS nutritional_assessments (
    id SERIAL PRIMARY KEY,
    patient_id INTEGER NOT NULL,
    eating_habits TEXT,
    water_intake VARCHAR(100),
    physical_activity VARCHAR(200),
    observations TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_assessment_patient
        FOREIGN KEY (patient_id) REFERENCES patients(id)
        ON DELETE CASCADE
);

-- 6. Tabela de Relatórios de Consulta (NOVA)
CREATE TABLE IF NOT EXISTS consultation_reports (
    id SERIAL PRIMARY KEY,
    consultation_id INTEGER NOT NULL,
    summary TEXT,
    alerts TEXT,
    reviewed BOOLEAN NOT NULL DEFAULT FALSE,
    generated_by_ai BOOLEAN NOT NULL DEFAULT FALSE,
    CONSTRAINT fk_report_consultation
        FOREIGN KEY (consultation_id) REFERENCES consultation(id)
        ON DELETE CASCADE
);

-- 7. Índices para performance
CREATE INDEX IF NOT EXISTS idx_consultation_patient
    ON consultation(patient_id);

CREATE INDEX IF NOT EXISTS idx_consultation_nutritionist
    ON consultation(nutritionist_id);

CREATE INDEX IF NOT EXISTS idx_consultation_status
    ON consultation(status);

CREATE INDEX IF NOT EXISTS idx_assessment_patient
    ON nutritional_assessments(patient_id);

CREATE INDEX IF NOT EXISTS idx_report_consultation
    ON consultation_reports(consultation_id);

CREATE INDEX IF NOT EXISTS idx_nutritionist_user
    ON nutritionists(user_id);

-- 8. Usuário padrão para login
-- Email: admin@nutrimind.com | Senha: admin123
INSERT INTO users (name, email, password, role, active)
SELECT 'Administrador', 'admin@nutrimind.com', 'admin123', 'NUTRITIONIST', TRUE
WHERE NOT EXISTS (
    SELECT 1 FROM users WHERE email = 'admin@nutrimind.com'
);

-- 9. Nutricionista vinculado ao usuário padrão
INSERT INTO nutritionists (user_id, crn)
SELECT u.id, 'CRN-8/12345'
FROM users u
WHERE u.email = 'admin@nutrimind.com'
AND NOT EXISTS (
    SELECT 1 FROM nutritionists n WHERE n.user_id = u.id
);

-- ============================================
-- FIM DO SCRIPT
-- ============================================
