package dao;

import connection.ConnectionFactory;
import model.ConsultationReport;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO para relatórios de consulta.
 */
public class ConsultationReportDAO
        implements GenericDAO<ConsultationReport> {

    @Override
    public void save(ConsultationReport report) {

        String sql = """
                INSERT INTO consultation_reports
                (consultation_id, summary, alerts, reviewed, generated_by_ai)
                VALUES (?, ?, ?, ?, ?)
                """;

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql)
        ) {

            stmt.setInt(1, report.getConsultationId());
            stmt.setString(2, report.getSummary());
            stmt.setString(3, report.getAlerts());
            stmt.setBoolean(4, report.isReviewed());
            stmt.setBoolean(5, report.isGeneratedByAI());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(ConsultationReport report) {

        String sql = """
                UPDATE consultation_reports
                SET
                    consultation_id = ?,
                    summary = ?,
                    alerts = ?,
                    reviewed = ?,
                    generated_by_ai = ?
                WHERE id = ?
                """;

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql)
        ) {

            stmt.setInt(1, report.getConsultationId());
            stmt.setString(2, report.getSummary());
            stmt.setString(3, report.getAlerts());
            stmt.setBoolean(4, report.isReviewed());
            stmt.setBoolean(5, report.isGeneratedByAI());
            stmt.setInt(6, report.getId());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id) {

        String sql = "DELETE FROM consultation_reports WHERE id = ?";

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql)
        ) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public ConsultationReport findById(int id) {

        String sql = "SELECT * FROM consultation_reports WHERE id = ?";

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql)
        ) {

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                ConsultationReport r = new ConsultationReport();

                r.setId(rs.getInt("id"));
                r.setConsultationId(rs.getInt("consultation_id"));
                r.setSummary(rs.getString("summary"));
                r.setAlerts(rs.getString("alerts"));
                r.setReviewed(rs.getBoolean("reviewed"));
                r.setGeneratedByAI(rs.getBoolean("generated_by_ai"));

                return r;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public List<ConsultationReport> findAll() {

        List<ConsultationReport> list = new ArrayList<>();

        String sql = "SELECT * FROM consultation_reports ORDER BY id";

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql);

                ResultSet rs = stmt.executeQuery()
        ) {

            while (rs.next()) {

                ConsultationReport r = new ConsultationReport();

                r.setId(rs.getInt("id"));
                r.setConsultationId(rs.getInt("consultation_id"));
                r.setSummary(rs.getString("summary"));
                r.setAlerts(rs.getString("alerts"));
                r.setReviewed(rs.getBoolean("reviewed"));
                r.setGeneratedByAI(rs.getBoolean("generated_by_ai"));

                list.add(r);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    /**
     * Busca relatório por ID da consulta.
     */
    public ConsultationReport findByConsultationId(int consultationId) {

        String sql = "SELECT * FROM consultation_reports WHERE consultation_id = ?";

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql)
        ) {

            stmt.setInt(1, consultationId);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                ConsultationReport r = new ConsultationReport();

                r.setId(rs.getInt("id"));
                r.setConsultationId(rs.getInt("consultation_id"));
                r.setSummary(rs.getString("summary"));
                r.setAlerts(rs.getString("alerts"));
                r.setReviewed(rs.getBoolean("reviewed"));
                r.setGeneratedByAI(rs.getBoolean("generated_by_ai"));

                return r;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }
}
