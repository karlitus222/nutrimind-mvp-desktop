package dao;

import connection.ConnectionFactory;
import model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * DAO responsável pela autenticação de usuários.
 */
public class UserDAO {

    /**
     * Autentica um usuário pelo email e senha.
     *
     * @param email Email do usuário
     * @param password Senha do usuário
     * @return User autenticado ou null se credenciais inválidas
     */
    public User authenticate(String email, String password) {

        String sql = """
                SELECT id, name, email, password, role, active
                FROM users
                WHERE email = ? AND password = ? AND active = true
                """;

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql)
        ) {

            stmt.setString(1, email);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                User user = new User();

                user.setId(rs.getInt("id"));
                user.setName(rs.getString("name"));
                user.setEmail(rs.getString("email"));
                user.setPassword(rs.getString("password"));
                user.setRole(rs.getString("role"));
                user.setActive(rs.getBoolean("active"));

                return user;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * Busca o ID do nutricionista vinculado ao usuário.
     *
     * @param userId ID do usuário
     * @return ID do nutricionista ou -1 se não encontrado
     */
    public int findNutritionistIdByUserId(int userId) {

        String sql = "SELECT id FROM nutritionists WHERE user_id = ?";

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql)
        ) {

            stmt.setInt(1, userId);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt("id");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return -1;
    }
}
