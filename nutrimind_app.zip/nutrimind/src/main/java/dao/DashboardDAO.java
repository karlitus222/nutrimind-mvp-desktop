package dao;

import connection.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * DAO responsável por indicadores do Dashboard.
 */
public class DashboardDAO {

    public int countPatients() {
        return executeCount("SELECT COUNT(*) FROM patients");
    }

    public int countConsultations() {
        return executeCount("SELECT COUNT(*) FROM consultation");
    }

    public int countPending() {
        return executeCount(
                "SELECT COUNT(*) FROM consultation WHERE status = 'PENDING'"
        );
    }

    public int countCompleted() {
        return executeCount(
                "SELECT COUNT(*) FROM consultation WHERE status = 'COMPLETED'"
        );
    }

    private int executeCount(String sql) {

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql);

                ResultSet rs = stmt.executeQuery()
        ) {

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }
}
