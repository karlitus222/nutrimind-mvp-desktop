package dao;

import connection.ConnectionFactory;
import model.Patient;

import java.sql.Connection;
import java.util.List;

import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;

public class PatientDAO implements GenericDAO<Patient> {

    @Override
public void save(Patient patient) {

    String sql = """
            INSERT INTO patients
            (
                name,
                birth_date,
                cpf,
                email,
                phone,
                active
            )
            VALUES
            (
                ?, ?, ?, ?, ?, ?
            )
            """;

    try (
            Connection conn =
                    ConnectionFactory
                            .getInstance()
                            .getConnection();

            var stmt =
                    conn.prepareStatement(sql)
    ) {

        stmt.setString(1, patient.getName());

        stmt.setDate(
                2,
                java.sql.Date.valueOf(
                        patient.getBirthDate()
                )
        );

        stmt.setString(3, patient.getCpf());

        stmt.setString(4, patient.getEmail());

        stmt.setString(5, patient.getPhone());

        stmt.setBoolean(6, patient.isActive());

        stmt.executeUpdate();

        System.out.println(
                "Paciente salvo com sucesso!"
        );

    } catch (Exception e) {

        e.printStackTrace();
    }
}

    @Override
public void update(Patient patient) {

    String sql = """
            UPDATE patients
            SET
                name = ?,
                birth_date = ?,
                cpf = ?,
                email = ?,
                phone = ?,
                active = ?
            WHERE id = ?
            """;

    try (
            Connection conn =
                    ConnectionFactory
                            .getInstance()
                            .getConnection();

            var stmt =
                    conn.prepareStatement(sql)
    ) {

        stmt.setString(
                1,
                patient.getName()
        );

        stmt.setDate(
                2,
                java.sql.Date.valueOf(
                        patient.getBirthDate()
                )
        );

        stmt.setString(
                3,
                patient.getCpf()
        );

        stmt.setString(
                4,
                patient.getEmail()
        );

        stmt.setString(
                5,
                patient.getPhone()
        );

        stmt.setBoolean(
                6,
                patient.isActive()
        );

        stmt.setInt(
                7,
                patient.getId()
        );

        stmt.executeUpdate();

    } catch (Exception e) {

        e.printStackTrace();
    }
}

    @Override
public void delete(int id) {

    String sql =
            "DELETE FROM patients WHERE id = ?";

    try (
            Connection conn =
                    ConnectionFactory
                            .getInstance()
                            .getConnection();

            var stmt =
                    conn.prepareStatement(sql)
    ) {

        stmt.setInt(1, id);

        stmt.executeUpdate();

        System.out.println(
                "Paciente excluído com sucesso!"
        );

    } catch (Exception e) {

        e.printStackTrace();
    }
}

   @Override
public Patient findById(int id) {

    String sql =
            "SELECT * FROM patients WHERE id = ?";

    try (
            Connection conn =
                    ConnectionFactory
                            .getInstance()
                            .getConnection();

            var stmt =
                    conn.prepareStatement(sql)
    ) {

        stmt.setInt(1, id);

        var rs = stmt.executeQuery();

        if (rs.next()) {

            Patient patient =
                    new Patient();

            patient.setId(
                    rs.getInt("id")
            );

            patient.setName(
                    rs.getString("name")
            );

            patient.setBirthDate(
                    rs.getDate("birth_date")
                            .toLocalDate()
            );

            patient.setCpf(
                    rs.getString("cpf")
            );

            patient.setEmail(
                    rs.getString("email")
            );

            patient.setPhone(
                    rs.getString("phone")
            );

            patient.setActive(
                    rs.getBoolean("active")
            );

            return patient;
        }

    } catch (Exception e) {

        e.printStackTrace();
    }

    return null;
}

    @Override
public List<Patient> findAll() {

    List<Patient> patients = new ArrayList<>();

    String sql = "SELECT * FROM patients ORDER BY id";

    try (
            Connection conn =
                    ConnectionFactory
                            .getInstance()
                            .getConnection();

            var stmt =
                    conn.prepareStatement(sql);

            ResultSet rs =
                    stmt.executeQuery()
    ) {

        while (rs.next()) {

            Patient patient = new Patient();

            patient.setId(
                    rs.getInt("id")
            );

            patient.setName(
                    rs.getString("name")
            );

            patient.setBirthDate(
                    rs.getDate("birth_date")
                            .toLocalDate()
            );

            patient.setCpf(
                    rs.getString("cpf")
            );

            patient.setEmail(
                    rs.getString("email")
            );

            patient.setPhone(
                    rs.getString("phone")
            );

            patient.setActive(
                    rs.getBoolean("active")
            );

            patients.add(patient);
        }

    } catch (Exception e) {

        e.printStackTrace();
    }

    return patients;
}
}