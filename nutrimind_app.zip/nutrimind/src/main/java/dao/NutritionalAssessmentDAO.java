package dao;

import connection.ConnectionFactory;
import model.NutritionalAssessment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO para avaliações nutricionais.
 */
public class NutritionalAssessmentDAO
        implements GenericDAO<NutritionalAssessment> {

    @Override
    public void save(NutritionalAssessment assessment) {

        String sql = """
                INSERT INTO nutritional_assessments
                (
                    patient_id,
                    eating_habits,
                    water_intake,
                    physical_activity,
                    observations
                )
                VALUES (?, ?, ?, ?, ?)
                """;

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql)
        ) {

            stmt.setInt(1, assessment.getPatientId());
            stmt.setString(2, assessment.getEatingHabits());
            stmt.setString(3, assessment.getWaterIntake());
            stmt.setString(4, assessment.getPhysicalActivity());
            stmt.setString(5, assessment.getObservations());

            stmt.executeUpdate();

            System.out.println("Avaliação salva com sucesso!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(NutritionalAssessment assessment) {

        String sql = """
                UPDATE nutritional_assessments
                SET
                    patient_id = ?,
                    eating_habits = ?,
                    water_intake = ?,
                    physical_activity = ?,
                    observations = ?
                WHERE id = ?
                """;

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql)
        ) {

            stmt.setInt(1, assessment.getPatientId());
            stmt.setString(2, assessment.getEatingHabits());
            stmt.setString(3, assessment.getWaterIntake());
            stmt.setString(4, assessment.getPhysicalActivity());
            stmt.setString(5, assessment.getObservations());
            stmt.setInt(6, assessment.getId());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id) {

        String sql = "DELETE FROM nutritional_assessments WHERE id = ?";

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql)
        ) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

            System.out.println("Avaliação excluída com sucesso!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public NutritionalAssessment findById(int id) {

        String sql = "SELECT * FROM nutritional_assessments WHERE id = ?";

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql)
        ) {

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                NutritionalAssessment a = new NutritionalAssessment();

                a.setId(rs.getInt("id"));
                a.setPatientId(rs.getInt("patient_id"));
                a.setEatingHabits(rs.getString("eating_habits"));
                a.setWaterIntake(rs.getString("water_intake"));
                a.setPhysicalActivity(rs.getString("physical_activity"));
                a.setObservations(rs.getString("observations"));
                a.setCreatedAt(rs.getString("created_at"));

                return a;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public List<NutritionalAssessment> findAll() {

        List<NutritionalAssessment> list = new ArrayList<>();

        String sql = "SELECT * FROM nutritional_assessments ORDER BY id";

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql);

                ResultSet rs = stmt.executeQuery()
        ) {

            while (rs.next()) {

                NutritionalAssessment a = new NutritionalAssessment();

                a.setId(rs.getInt("id"));
                a.setPatientId(rs.getInt("patient_id"));
                a.setEatingHabits(rs.getString("eating_habits"));
                a.setWaterIntake(rs.getString("water_intake"));
                a.setPhysicalActivity(rs.getString("physical_activity"));
                a.setObservations(rs.getString("observations"));
                a.setCreatedAt(rs.getString("created_at"));

                list.add(a);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    /**
     * Busca avaliações com JOIN para exibir nome do paciente.
     */
    public List<NutritionalAssessment> findAllWithJoin() {

        List<NutritionalAssessment> list = new ArrayList<>();

        String sql = """
                SELECT na.*, p.name AS patient_name
                FROM nutritional_assessments na
                LEFT JOIN patients p ON na.patient_id = p.id
                ORDER BY na.id
                """;

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql);

                ResultSet rs = stmt.executeQuery()
        ) {

            while (rs.next()) {

                NutritionalAssessment a = new NutritionalAssessment();

                a.setId(rs.getInt("id"));
                a.setPatientId(rs.getInt("patient_id"));
                a.setEatingHabits(rs.getString("eating_habits"));
                a.setWaterIntake(rs.getString("water_intake"));
                a.setPhysicalActivity(rs.getString("physical_activity"));
                a.setObservations(rs.getString("observations"));
                a.setCreatedAt(rs.getString("created_at"));
                a.setPatientName(rs.getString("patient_name"));

                list.add(a);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    /**
     * Busca avaliações por paciente.
     */
    public List<NutritionalAssessment> findByPatientId(int patientId) {

        List<NutritionalAssessment> list = new ArrayList<>();

        String sql = "SELECT * FROM nutritional_assessments WHERE patient_id = ? ORDER BY id";

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql)
        ) {

            stmt.setInt(1, patientId);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                NutritionalAssessment a = new NutritionalAssessment();

                a.setId(rs.getInt("id"));
                a.setPatientId(rs.getInt("patient_id"));
                a.setEatingHabits(rs.getString("eating_habits"));
                a.setWaterIntake(rs.getString("water_intake"));
                a.setPhysicalActivity(rs.getString("physical_activity"));
                a.setObservations(rs.getString("observations"));
                a.setCreatedAt(rs.getString("created_at"));

                list.add(a);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}
