package dao;

import connection.ConnectionFactory;
import model.Consultation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ConsultationDAO
        implements GenericDAO<Consultation> {

    @Override
    public void save(Consultation consultation) {

        String sql = """
                INSERT INTO consultation
                (
                    patient_id,
                    nutritionist_id,
                    date,
                    notes,
                    status
                )
                VALUES (?, ?, ?, ?, ?)
                """;

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql)
        ) {

            stmt.setInt(1, consultation.getPatientId());
            stmt.setInt(2, consultation.getNutritionistId());
            stmt.setString(3, consultation.getDate());
            stmt.setString(4, consultation.getNotes());
            stmt.setString(5, consultation.getStatus());

            stmt.executeUpdate();

            System.out.println("Consulta salva com sucesso!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(Consultation consultation) {

        String sql = """
                UPDATE consultation
                SET
                    patient_id = ?,
                    nutritionist_id = ?,
                    date = ?,
                    notes = ?,
                    status = ?
                WHERE id = ?
                """;

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql)
        ) {

            stmt.setInt(1, consultation.getPatientId());
            stmt.setInt(2, consultation.getNutritionistId());
            stmt.setString(3, consultation.getDate());
            stmt.setString(4, consultation.getNotes());
            stmt.setString(5, consultation.getStatus());
            stmt.setInt(6, consultation.getId());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id) {

        String sql = "DELETE FROM consultation WHERE id = ?";

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql)
        ) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

            System.out.println("Consulta excluída com sucesso!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public Consultation findById(int id) {

        String sql = "SELECT * FROM consultation WHERE id = ?";

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql)
        ) {

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                Consultation c = new Consultation();

                c.setId(rs.getInt("id"));
                c.setPatientId(rs.getInt("patient_id"));
                c.setNutritionistId(rs.getInt("nutritionist_id"));
                c.setDate(rs.getString("date"));
                c.setNotes(rs.getString("notes"));
                c.setStatus(rs.getString("status"));

                return c;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public List<Consultation> findAll() {

        List<Consultation> consultations = new ArrayList<>();

        String sql = "SELECT * FROM consultation ORDER BY id";

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql);

                ResultSet rs = stmt.executeQuery()
        ) {

            while (rs.next()) {

                Consultation c = new Consultation();

                c.setId(rs.getInt("id"));
                c.setPatientId(rs.getInt("patient_id"));
                c.setNutritionistId(rs.getInt("nutritionist_id"));
                c.setDate(rs.getString("date"));
                c.setNotes(rs.getString("notes"));
                c.setStatus(rs.getString("status"));

                consultations.add(c);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return consultations;
    }

    /**
     * Busca todas as consultas utilizando JOIN com patients e nutritionists
     * para exibir nomes ao invés de IDs na interface.
     */
    public List<Consultation> findAllWithJoin() {

        List<Consultation> consultations = new ArrayList<>();

        String sql = """
                SELECT c.id,
                       c.patient_id,
                       c.nutritionist_id,
                       c.date,
                       c.notes,
                       c.status,
                       p.name AS patient_name,
                       n.crn AS nutritionist_crn
                FROM consultation c
                LEFT JOIN patients p ON c.patient_id = p.id
                LEFT JOIN nutritionists n ON c.nutritionist_id = n.id
                ORDER BY c.id
                """;

        try (
                Connection conn =
                        ConnectionFactory
                                .getInstance()
                                .getConnection();

                PreparedStatement stmt =
                        conn.prepareStatement(sql);

                ResultSet rs = stmt.executeQuery()
        ) {

            while (rs.next()) {

                Consultation c = new Consultation();

                c.setId(rs.getInt("id"));
                c.setPatientId(rs.getInt("patient_id"));
                c.setNutritionistId(rs.getInt("nutritionist_id"));
                c.setDate(rs.getString("date"));
                c.setNotes(rs.getString("notes"));
                c.setStatus(rs.getString("status"));
                c.setPatientName(rs.getString("patient_name"));
                c.setNutritionistCrn(rs.getString("nutritionist_crn"));

                consultations.add(c);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return consultations;
    }
}