package main;

import dao.PatientDAO;
import model.Patient;

import java.time.LocalDate;

public class TestPatientInsert {

    public static void main(String[] args) {

        Patient patient = new Patient();

        patient.setName("Gabriel Oliveira");

        patient.setBirthDate(
                LocalDate.of(2000, 6, 22)
        );

        patient.setCpf("11122233344");

        patient.setEmail(
                "gabriel@email.com"
        );

        patient.setPhone(
                "85999999999"
        );

        patient.setActive(true);

        new PatientDAO().save(patient);
    }
}
