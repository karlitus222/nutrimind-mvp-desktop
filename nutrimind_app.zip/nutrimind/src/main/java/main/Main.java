package main;

import controller.LoginController;

import javax.swing.*;

/**
 * Classe principal do NutriMind.
 * Inicia o sistema pela tela de login.
 */
public class Main {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(
                () -> new LoginController()
        );
    }
}