package main;

import dao.PatientDAO;
import model.Patient;

import java.util.List;

public class TestPatientList {

    public static void main(String[] args) {

        List<Patient> patients =
                new PatientDAO()
                        .findAll();

        for (Patient p : patients) {

            System.out.println(
                    p.getId()
                    + " - "
                    + p.getName()
                    + " - "
                    + p.getCpf()
            );
        }
    }
}