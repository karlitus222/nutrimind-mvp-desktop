package main;

import connection.ConnectionFactory;
import java.sql.Connection;

public class TestConnection {

    public static void main(String[] args) {

        try {

            Connection conn =
                    ConnectionFactory
                            .getInstance()
                            .getConnection();

            if (conn != null) {
                System.out.println("Conexão realizada com sucesso!");
            }

            conn.close();

        } catch (Exception e) {

            System.out.println(
                    "Erro ao conectar: "
                            + e.getMessage()
            );

            e.printStackTrace();
        }
    }
}