package controller;

import dao.PatientDAO;
import model.Patient;
import view.PatientView;
import view.PatientFormView;

import javax.swing.*;
import java.util.List;

/**
 * Controller para CRUD completo de Pacientes.
 */
public class PatientController {

    private PatientView view;
    private PatientDAO dao;

    public PatientController() {

        view = new PatientView();
        dao = new PatientDAO();

        loadPatients();

        view.getBtnNew().addActionListener(
                e -> openPatientForm(null)
        );

        view.getBtnEdit().addActionListener(
                e -> editPatient()
        );

        view.getBtnDelete().addActionListener(
                e -> deletePatient()
        );
    }

    private void loadPatients() {

        List<Patient> patients = dao.findAll();

        for (Patient p : patients) {

            view.getModel().addRow(
                    new Object[]{
                            p.getId(),
                            p.getName(),
                            p.getCpf(),
                            p.getEmail(),
                            p.getPhone()
                    }
            );
        }
    }

    private void refreshTable() {

        view.getModel().setRowCount(0);
        loadPatients();
    }

    private void openPatientForm(Patient existing) {

        PatientFormView form =
                new PatientFormView(view);

        if (existing != null) {

            form.setTitle("Editar Paciente");
            form.getTxtName().setText(
                    existing.getName()
            );
            form.getTxtCpf().setText(
                    existing.getCpf()
            );
            form.getTxtEmail().setText(
                    existing.getEmail()
            );
            form.getTxtPhone().setText(
                    existing.getPhone()
            );
        }

        form.getBtnSave().addActionListener(e -> {

            String name =
                    form.getTxtName()
                            .getText().trim();

            String cpf =
                    form.getTxtCpf()
                            .getText().trim();

            // Validação: Nome obrigatório
            if (name.isEmpty()) {

                JOptionPane.showMessageDialog(
                        form,
                        "O nome é obrigatório.",
                        "Validação",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            // Validação: CPF obrigatório
            if (cpf.isEmpty()) {

                JOptionPane.showMessageDialog(
                        form,
                        "O CPF é obrigatório.",
                        "Validação",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            if (existing != null) {

                // Edição
                existing.setName(name);
                existing.setCpf(cpf);
                existing.setEmail(
                        form.getTxtEmail()
                                .getText().trim()
                );
                existing.setPhone(
                        form.getTxtPhone()
                                .getText().trim()
                );

                dao.update(existing);

                JOptionPane.showMessageDialog(
                        form,
                        "Paciente atualizado com sucesso!"
                );

            } else {

                // Novo
                Patient patient = new Patient();

                patient.setName(name);
                patient.setCpf(cpf);
                patient.setEmail(
                        form.getTxtEmail()
                                .getText().trim()
                );
                patient.setPhone(
                        form.getTxtPhone()
                                .getText().trim()
                );
                patient.setBirthDate(
                        java.time.LocalDate.now()
                );
                patient.setActive(true);

                dao.save(patient);

                JOptionPane.showMessageDialog(
                        form,
                        "Paciente cadastrado com sucesso!"
                );
            }

            refreshTable();
            form.dispose();
        });
    }

    private void editPatient() {

        int selectedRow =
                view.getTable().getSelectedRow();

        if (selectedRow == -1) {

            JOptionPane.showMessageDialog(
                    view,
                    "Selecione um paciente para editar.",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int id = (int) view.getTable()
                .getValueAt(selectedRow, 0);

        Patient patient = dao.findById(id);

        if (patient != null) {
            openPatientForm(patient);
        }
    }

    private void deletePatient() {

        int selectedRow =
                view.getTable().getSelectedRow();

        if (selectedRow == -1) {

            JOptionPane.showMessageDialog(
                    view,
                    "Selecione um paciente.",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int id = (int) view.getTable()
                .getValueAt(selectedRow, 0);

        int option =
                JOptionPane.showConfirmDialog(
                        view,
                        "Deseja realmente excluir?",
                        "Confirmação",
                        JOptionPane.YES_NO_OPTION
                );

        if (option ==
                JOptionPane.YES_OPTION) {

            dao.delete(id);
            refreshTable();

            JOptionPane.showMessageDialog(
                    view,
                    "Paciente excluído com sucesso!"
            );
        }
    }
}