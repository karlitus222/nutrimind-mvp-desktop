package controller;

import dao.ConsultationDAO;
import dao.ConsultationReportDAO;
import dao.NutritionalAssessmentDAO;
import model.Consultation;
import model.ConsultationReport;
import model.NutritionalAssessment;
import view.ReportView;

import javax.swing.*;
import java.util.List;

/**
 * Controller para visualização e geração de relatórios.
 * Gera resumos simples sem IA.
 */
public class ReportController {

    private ReportView view;
    private ConsultationDAO consultationDAO;
    private ConsultationReportDAO reportDAO;
    private NutritionalAssessmentDAO assessmentDAO;

    public ReportController() {

        view = new ReportView();
        consultationDAO = new ConsultationDAO();
        reportDAO = new ConsultationReportDAO();
        assessmentDAO =
                new NutritionalAssessmentDAO();

        loadConsultations();

        view.getBtnGenerate().addActionListener(
                e -> generateReport()
        );

        view.getBtnView().addActionListener(
                e -> viewReport()
        );
    }

    private void loadConsultations() {

        List<Consultation> consultations =
                consultationDAO.findAllWithJoin();

        for (Consultation c : consultations) {

            String patientDisplay =
                    c.getPatientName() != null
                            ? c.getPatientName()
                            : "ID: " + c.getPatientId();

            String nutriDisplay =
                    c.getNutritionistCrn() != null
                            ? c.getNutritionistCrn()
                            : "ID: " + c.getNutritionistId();

            view.getModel().addRow(
                    new Object[]{
                            c.getId(),
                            patientDisplay,
                            nutriDisplay,
                            c.getDate(),
                            c.getStatus(),
                            c.getNotes()
                    }
            );
        }
    }

    /**
     * Gera resumo simples da consulta selecionada.
     * Sem IA - utiliza regras simples.
     */
    private void generateReport() {

        int selectedRow =
                view.getTable().getSelectedRow();

        if (selectedRow == -1) {

            JOptionPane.showMessageDialog(
                    view,
                    "Selecione uma consulta para gerar o resumo.",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int consultationId = (int)
                view.getTable()
                        .getValueAt(selectedRow, 0);

        Consultation consultation =
                consultationDAO.findById(
                        consultationId
                );

        if (consultation == null) {
            return;
        }

        // Buscar avaliações do paciente
        List<NutritionalAssessment> assessments =
                assessmentDAO.findByPatientId(
                        consultation.getPatientId()
                );

        // Gerar resumo simples
        StringBuilder summary =
                new StringBuilder();

        summary.append(
                "=== RESUMO DA CONSULTA ==="
        );
        summary.append("\n");
        summary.append(
                "ID da Consulta: "
        ).append(consultation.getId());
        summary.append("\n");
        summary.append(
                "Data: "
        ).append(consultation.getDate());
        summary.append("\n");
        summary.append(
                "Status: "
        ).append(consultation.getStatus());
        summary.append("\n");
        summary.append(
                "Observações: "
        ).append(
                consultation.getNotes() != null
                        ? consultation.getNotes()
                        : "Nenhuma"
        );
        summary.append("\n\n");

        // Alertas simples
        StringBuilder alerts =
                new StringBuilder();

        if ("PENDING".equals(
                consultation.getStatus())) {

            alerts.append(
                    "[ALERTA] Consulta ainda pendente.\n"
            );
        }

        if (assessments.isEmpty()) {

            alerts.append(
                    "[ALERTA] Nenhuma avaliação nutricional registrada para este paciente.\n"
            );

        } else {

            summary.append(
                    "=== AVALIAÇÕES NUTRICIONAIS ==="
            );
            summary.append("\n");

            for (NutritionalAssessment a
                    : assessments) {

                summary.append(
                        "- Hábitos: "
                ).append(a.getEatingHabits());
                summary.append("\n");

                summary.append(
                        "  Água: "
                ).append(a.getWaterIntake());
                summary.append("\n");

                summary.append(
                        "  Atividade: "
                ).append(a.getPhysicalActivity());
                summary.append("\n");

                summary.append(
                        "  Obs: "
                ).append(a.getObservations());
                summary.append("\n\n");
            }
        }

        if (alerts.length() > 0) {
            summary.append("\n");
            summary.append(
                    "=== ALERTAS ==="
            );
            summary.append("\n");
            summary.append(alerts);
        }

        summary.append("\n");
        summary.append(
                "--- Relatório gerado por regras simples (sem IA) ---"
        );

        // Salvar relatório no banco
        ConsultationReport report =
                new ConsultationReport();

        report.setConsultationId(consultationId);
        report.setSummary(summary.toString());
        report.setAlerts(alerts.toString());
        report.setReviewed(false);
        report.setGeneratedByAI(false);

        // Verificar se já existe
        ConsultationReport existing =
                reportDAO.findByConsultationId(
                        consultationId
                );

        if (existing != null) {
            report.setId(existing.getId());
            reportDAO.update(report);
        } else {
            reportDAO.save(report);
        }

        view.getTxtReportContent().setText(
                summary.toString()
        );

        JOptionPane.showMessageDialog(
                view,
                "Resumo gerado com sucesso!"
        );
    }

    /**
     * Visualiza relatório existente da consulta selecionada.
     */
    private void viewReport() {

        int selectedRow =
                view.getTable().getSelectedRow();

        if (selectedRow == -1) {

            JOptionPane.showMessageDialog(
                    view,
                    "Selecione uma consulta.",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int consultationId = (int)
                view.getTable()
                        .getValueAt(selectedRow, 0);

        ConsultationReport report =
                reportDAO.findByConsultationId(
                        consultationId
                );

        if (report != null) {

            view.getTxtReportContent().setText(
                    report.getSummary()
            );

        } else {

            view.getTxtReportContent().setText(
                    "Nenhum relatório encontrado para esta consulta.\n"
                    + "Clique em 'Gerar Resumo da Consulta' para criar um."
            );
        }
    }
}
