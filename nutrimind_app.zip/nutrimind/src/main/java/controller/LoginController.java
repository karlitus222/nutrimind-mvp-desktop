package controller;

import dao.UserDAO;
import model.User;
import view.LoginView;

import javax.swing.*;

/**
 * Controller responsável pela autenticação de usuários.
 */
public class LoginController {

    private LoginView view;
    private UserDAO userDAO;

    public LoginController() {

        view = new LoginView();
        userDAO = new UserDAO();

        view.getBtnLogin().addActionListener(
                e -> doLogin()
        );

        // Permitir login com Enter no campo de senha
        view.getTxtPassword().addActionListener(
                e -> doLogin()
        );
    }

    private void doLogin() {

        String email =
                view.getTxtEmail().getText().trim();

        String password =
                new String(
                        view.getTxtPassword()
                                .getPassword()
                );

        if (email.isEmpty() || password.isEmpty()) {

            JOptionPane.showMessageDialog(
                    view,
                    "Preencha todos os campos.",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        User user = userDAO.authenticate(
                email, password
        );

        if (user != null) {

            int nutritionistId =
                    userDAO.findNutritionistIdByUserId(
                            user.getId()
                    );

            view.dispose();

            new DashboardController(
                    user, nutritionistId
            );

        } else {

            JOptionPane.showMessageDialog(
                    view,
                    "Email ou senha inválidos.",
                    "Erro de Autenticação",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
}
