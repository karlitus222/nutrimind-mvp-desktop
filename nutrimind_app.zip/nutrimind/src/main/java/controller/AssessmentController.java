package controller;

import dao.NutritionalAssessmentDAO;
import dao.PatientDAO;
import model.NutritionalAssessment;
import model.Patient;
import view.AssessmentView;
import view.AssessmentFormView;

import javax.swing.*;
import java.util.List;

/**
 * Controller para CRUD completo de Avaliações Nutricionais.
 */
public class AssessmentController {

    private AssessmentView view;
    private NutritionalAssessmentDAO dao;

    public AssessmentController() {

        view = new AssessmentView();
        dao = new NutritionalAssessmentDAO();

        loadAssessments();

        view.getBtnNew().addActionListener(
                e -> openForm(null)
        );

        view.getBtnEdit().addActionListener(
                e -> editAssessment()
        );

        view.getBtnDelete().addActionListener(
                e -> deleteAssessment()
        );
    }

    private void loadAssessments() {

        List<NutritionalAssessment> list =
                dao.findAllWithJoin();

        for (NutritionalAssessment a : list) {

            String patientDisplay =
                    a.getPatientName() != null
                            ? a.getPatientName()
                            : "ID: " + a.getPatientId();

            view.getModel().addRow(
                    new Object[]{
                            a.getId(),
                            patientDisplay,
                            a.getEatingHabits(),
                            a.getWaterIntake(),
                            a.getPhysicalActivity(),
                            a.getCreatedAt()
                    }
            );
        }
    }

    private void refreshTable() {

        view.getModel().setRowCount(0);
        loadAssessments();
    }

    private void openForm(
            NutritionalAssessment existing) {

        AssessmentFormView form =
                new AssessmentFormView(view);

        PatientDAO patientDAO = new PatientDAO();

        List<Patient> patients =
                patientDAO.findAll();

        for (Patient p : patients) {
            form.getCbPatients().addItem(p);
        }

        if (existing != null) {

            form.setTitle(
                    "Editar Avaliação Nutricional"
            );

            // Selecionar paciente correto
            for (int i = 0;
                 i < form.getCbPatients()
                         .getItemCount(); i++) {

                Patient p = form.getCbPatients()
                        .getItemAt(i);

                if (p.getId() ==
                        existing.getPatientId()) {

                    form.getCbPatients()
                            .setSelectedIndex(i);
                    break;
                }
            }

            form.getTxtEatingHabits().setText(
                    existing.getEatingHabits()
            );

            form.getTxtWaterIntake().setText(
                    existing.getWaterIntake()
            );

            form.getTxtPhysicalActivity().setText(
                    existing.getPhysicalActivity()
            );

            form.getTxtObservations().setText(
                    existing.getObservations()
            );
        }

        form.getBtnSave().addActionListener(e -> {

            Patient patient =
                    (Patient) form.getCbPatients()
                            .getSelectedItem();

            if (patient == null) {

                JOptionPane.showMessageDialog(
                        form,
                        "Selecione um paciente.",
                        "Validação",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            if (existing != null) {

                existing.setPatientId(
                        patient.getId()
                );
                existing.setEatingHabits(
                        form.getTxtEatingHabits()
                                .getText()
                );
                existing.setWaterIntake(
                        form.getTxtWaterIntake()
                                .getText()
                );
                existing.setPhysicalActivity(
                        form.getTxtPhysicalActivity()
                                .getText()
                );
                existing.setObservations(
                        form.getTxtObservations()
                                .getText()
                );

                dao.update(existing);

                JOptionPane.showMessageDialog(
                        form,
                        "Avaliação atualizada com sucesso!"
                );

            } else {

                NutritionalAssessment assessment =
                        new NutritionalAssessment();

                assessment.setPatientId(
                        patient.getId()
                );
                assessment.setEatingHabits(
                        form.getTxtEatingHabits()
                                .getText()
                );
                assessment.setWaterIntake(
                        form.getTxtWaterIntake()
                                .getText()
                );
                assessment.setPhysicalActivity(
                        form.getTxtPhysicalActivity()
                                .getText()
                );
                assessment.setObservations(
                        form.getTxtObservations()
                                .getText()
                );

                dao.save(assessment);

                JOptionPane.showMessageDialog(
                        form,
                        "Avaliação cadastrada com sucesso!"
                );
            }

            refreshTable();
            form.dispose();
        });
    }

    private void editAssessment() {

        int selectedRow =
                view.getTable().getSelectedRow();

        if (selectedRow == -1) {

            JOptionPane.showMessageDialog(
                    view,
                    "Selecione uma avaliação para editar.",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int id = (int) view.getTable()
                .getValueAt(selectedRow, 0);

        NutritionalAssessment assessment =
                dao.findById(id);

        if (assessment != null) {
            openForm(assessment);
        }
    }

    private void deleteAssessment() {

        int selectedRow =
                view.getTable().getSelectedRow();

        if (selectedRow == -1) {

            JOptionPane.showMessageDialog(
                    view,
                    "Selecione uma avaliação.",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int id = (int) view.getTable()
                .getValueAt(selectedRow, 0);

        int option =
                JOptionPane.showConfirmDialog(
                        view,
                        "Deseja realmente excluir?",
                        "Confirmação",
                        JOptionPane.YES_NO_OPTION
                );

        if (option ==
                JOptionPane.YES_OPTION) {

            dao.delete(id);
            refreshTable();

            JOptionPane.showMessageDialog(
                    view,
                    "Avaliação excluída com sucesso!"
            );
        }
    }
}
