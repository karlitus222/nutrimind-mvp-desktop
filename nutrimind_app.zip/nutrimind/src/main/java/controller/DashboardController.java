package controller;

import dao.DashboardDAO;
import model.User;
import view.DashboardView;

import javax.swing.*;

/**
 * Controller do Dashboard principal.
 * Carrega indicadores e gerencia navegação.
 */
public class DashboardController {

    private DashboardView view;
    private DashboardDAO dashboardDAO;
    private User loggedUser;
    private int nutritionistId;

    public DashboardController(
            User user, int nutritionistId) {

        this.loggedUser = user;
        this.nutritionistId = nutritionistId;

        view = new DashboardView();
        dashboardDAO = new DashboardDAO();

        loadIndicators();
        setupListeners();
    }

    private void loadIndicators() {

        try {

            view.getLblTotalPatients().setText(
                    String.valueOf(
                            dashboardDAO.countPatients()
                    )
            );

            view.getLblTotalConsultations().setText(
                    String.valueOf(
                            dashboardDAO.countConsultations()
                    )
            );

            view.getLblPending().setText(
                    String.valueOf(
                            dashboardDAO.countPending()
                    )
            );

            view.getLblCompleted().setText(
                    String.valueOf(
                            dashboardDAO.countCompleted()
                    )
            );

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setupListeners() {

        view.getBtnPatients().addActionListener(
                e -> new PatientController()
        );

        view.getBtnConsultations().addActionListener(
                e -> new ConsultationController(
                        nutritionistId
                )
        );

        view.getBtnAssessments().addActionListener(
                e -> new AssessmentController()
        );

        view.getBtnReports().addActionListener(
                e -> new ReportController()
        );

        view.getBtnLogout().addActionListener(e -> {

            int option =
                    JOptionPane.showConfirmDialog(
                            view,
                            "Deseja realmente sair?",
                            "Confirmação",
                            JOptionPane.YES_NO_OPTION
                    );

            if (option ==
                    JOptionPane.YES_OPTION) {

                view.dispose();
                new LoginController();
            }
        });
    }
}
