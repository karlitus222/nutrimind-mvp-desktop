package controller;

import dao.ConsultationDAO;
import dao.PatientDAO;
import model.Consultation;
import model.Patient;
import view.ConsultationFormView;
import view.ConsultationView;

import javax.swing.*;
import java.util.List;

/**
 * Controller para CRUD completo de Consultas.
 * Utiliza JOIN para exibir nomes ao invés de IDs.
 */
public class ConsultationController {

    private ConsultationView view;
    private ConsultationDAO dao;
    private int nutritionistId;

    public ConsultationController(int nutritionistId) {

        this.nutritionistId = nutritionistId;

        view = new ConsultationView();
        dao = new ConsultationDAO();

        loadConsultations();

        view.getBtnNew().addActionListener(
                e -> openForm(null)
        );

        view.getBtnEdit().addActionListener(
                e -> editConsultation()
        );

        view.getBtnDelete().addActionListener(
                e -> deleteConsultation()
        );
    }

    /**
     * Carrega consultas com JOIN para exibir
     * nomes de pacientes e CRN do nutricionista.
     */
    private void loadConsultations() {

        List<Consultation> consultations =
                dao.findAllWithJoin();

        for (Consultation c : consultations) {

            String patientDisplay =
                    c.getPatientName() != null
                            ? c.getPatientName()
                            : "ID: " + c.getPatientId();

            String nutriDisplay =
                    c.getNutritionistCrn() != null
                            ? c.getNutritionistCrn()
                            : "ID: " + c.getNutritionistId();

            view.getModel().addRow(
                    new Object[]{
                            c.getId(),
                            patientDisplay,
                            nutriDisplay,
                            c.getDate(),
                            c.getStatus()
                    }
            );
        }
    }

    private void refreshTable() {

        view.getModel().setRowCount(0);
        loadConsultations();
    }

    private void openForm(Consultation existing) {

        ConsultationFormView form =
                new ConsultationFormView(view);

        PatientDAO patientDAO = new PatientDAO();

        List<Patient> patients =
                patientDAO.findAll();

        for (Patient p : patients) {
            form.getCbPatients().addItem(p);
        }

        if (existing != null) {

            form.setTitle("Editar Consulta");

            // Selecionar paciente correto
            for (int i = 0;
                 i < form.getCbPatients()
                         .getItemCount(); i++) {

                Patient p = form.getCbPatients()
                        .getItemAt(i);

                if (p.getId() ==
                        existing.getPatientId()) {

                    form.getCbPatients()
                            .setSelectedIndex(i);
                    break;
                }
            }

            form.getTxtDate().setText(
                    existing.getDate()
            );

            form.getCbStatus().setSelectedItem(
                    existing.getStatus()
            );

            form.getTxtNotes().setText(
                    existing.getNotes()
            );
        }

        form.getBtnSave().addActionListener(e -> {

            Patient patient =
                    (Patient) form.getCbPatients()
                            .getSelectedItem();

            if (patient == null) {

                JOptionPane.showMessageDialog(
                        form,
                        "Selecione um paciente.",
                        "Validação",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            String date =
                    form.getTxtDate()
                            .getText().trim();

            if (date.isEmpty()) {

                JOptionPane.showMessageDialog(
                        form,
                        "Informe a data da consulta.",
                        "Validação",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            if (existing != null) {

                // Edição
                existing.setPatientId(
                        patient.getId()
                );
                existing.setDate(date);
                existing.setNotes(
                        form.getTxtNotes().getText()
                );
                existing.setStatus(
                        form.getCbStatus()
                                .getSelectedItem()
                                .toString()
                );

                dao.update(existing);

                JOptionPane.showMessageDialog(
                        form,
                        "Consulta atualizada com sucesso!"
                );

            } else {

                // Nova
                Consultation consultation =
                        new Consultation();

                consultation.setPatientId(
                        patient.getId()
                );
                consultation.setNutritionistId(
                        nutritionistId
                );
                consultation.setDate(date);
                consultation.setNotes(
                        form.getTxtNotes().getText()
                );
                consultation.setStatus(
                        form.getCbStatus()
                                .getSelectedItem()
                                .toString()
                );

                dao.save(consultation);

                JOptionPane.showMessageDialog(
                        form,
                        "Consulta cadastrada com sucesso!"
                );
            }

            refreshTable();
            form.dispose();
        });
    }

    private void editConsultation() {

        int selectedRow =
                view.getTable().getSelectedRow();

        if (selectedRow == -1) {

            JOptionPane.showMessageDialog(
                    view,
                    "Selecione uma consulta para editar.",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int id = (int) view.getTable()
                .getValueAt(selectedRow, 0);

        Consultation consultation =
                dao.findById(id);

        if (consultation != null) {
            openForm(consultation);
        }
    }

    private void deleteConsultation() {

        int selectedRow =
                view.getTable().getSelectedRow();

        if (selectedRow == -1) {

            JOptionPane.showMessageDialog(
                    view,
                    "Selecione uma consulta.",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int id = (int) view.getTable()
                .getValueAt(selectedRow, 0);

        int option =
                JOptionPane.showConfirmDialog(
                        view,
                        "Deseja realmente excluir?",
                        "Confirmação",
                        JOptionPane.YES_NO_OPTION
                );

        if (option ==
                JOptionPane.YES_OPTION) {

            dao.delete(id);
            refreshTable();

            JOptionPane.showMessageDialog(
                    view,
                    "Consulta excluída com sucesso!"
            );
        }
    }
}