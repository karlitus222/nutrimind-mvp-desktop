package view;

import javax.swing.*;
import java.awt.*;

public class LoginView extends JFrame {

    private JTextField txtEmail;
    private JPasswordField txtPassword;
    private JButton btnLogin;

    public LoginView() {

        setTitle("NutriMind - Login");
        setSize(420, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        createComponents();

        setVisible(true);
    }

    private void createComponents() {

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(20, 30, 20, 30)
        );

        // Título
        JLabel title = new JLabel(
                "NUTRIMIND",
                SwingConstants.CENTER
        );
        title.setFont(
                new Font("Arial", Font.BOLD, 28)
        );
        mainPanel.add(title, BorderLayout.NORTH);

        // Formulário
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(3, 2, 10, 10));

        formPanel.add(new JLabel("Email:"));
        txtEmail = new JTextField();
        formPanel.add(txtEmail);

        formPanel.add(new JLabel("Senha:"));
        txtPassword = new JPasswordField();
        formPanel.add(txtPassword);

        formPanel.add(new JLabel()); // espaço vazio
        btnLogin = new JButton("Entrar");
        btnLogin.setFont(
                new Font("Arial", Font.BOLD, 14)
        );
        formPanel.add(btnLogin);

        mainPanel.add(formPanel, BorderLayout.CENTER);

        // Rodapé
        JLabel footer = new JLabel(
                "Sistema para Nutricionistas",
                SwingConstants.CENTER
        );
        footer.setFont(
                new Font("Arial", Font.ITALIC, 11)
        );
        mainPanel.add(footer, BorderLayout.SOUTH);

        setContentPane(mainPanel);
    }

    public JTextField getTxtEmail() {
        return txtEmail;
    }

    public JPasswordField getTxtPassword() {
        return txtPassword;
    }

    public JButton getBtnLogin() {
        return btnLogin;
    }
}
