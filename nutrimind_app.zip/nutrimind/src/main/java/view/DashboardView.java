package view;

import javax.swing.*;
import java.awt.*;

public class DashboardView extends JFrame {

    private JButton btnPatients;
    private JButton btnConsultations;
    private JButton btnAssessments;
    private JButton btnReports;
    private JButton btnLogout;

    private JLabel lblTotalPatients;
    private JLabel lblTotalConsultations;
    private JLabel lblPending;
    private JLabel lblCompleted;

    public DashboardView() {

        setTitle("NutriMind - Dashboard");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        createComponents();

        setVisible(true);
    }

    private void createComponents() {

        // === Painel Superior (Título + Logout) ===
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(
                BorderFactory.createEmptyBorder(10, 20, 10, 20)
        );

        JLabel title = new JLabel("NUTRIMIND");
        title.setFont(
                new Font("Arial", Font.BOLD, 28)
        );
        topPanel.add(title, BorderLayout.WEST);

        btnLogout = new JButton("Sair");
        JPanel logoutPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        logoutPanel.add(btnLogout);
        topPanel.add(logoutPanel, BorderLayout.EAST);

        add(topPanel, BorderLayout.NORTH);

        // === Painel de Indicadores ===
        JPanel indicatorsPanel = new JPanel(
                new GridLayout(1, 4, 15, 15)
        );
        indicatorsPanel.setBorder(
                BorderFactory.createEmptyBorder(10, 20, 10, 20)
        );

        lblTotalPatients = createIndicatorCard(
                "Total de Pacientes", "0", indicatorsPanel
        );

        lblTotalConsultations = createIndicatorCard(
                "Total de Consultas", "0", indicatorsPanel
        );

        lblPending = createIndicatorCard(
                "Consultas Pendentes", "0", indicatorsPanel
        );

        lblCompleted = createIndicatorCard(
                "Consultas Concluídas", "0", indicatorsPanel
        );

        add(indicatorsPanel, BorderLayout.CENTER);

        // === Painel de Botões de Navegação ===
        JPanel navPanel = new JPanel(
                new GridLayout(1, 4, 15, 15)
        );
        navPanel.setBorder(
                BorderFactory.createEmptyBorder(10, 20, 30, 20)
        );

        btnPatients = new JButton("Pacientes");
        btnPatients.setFont(
                new Font("Arial", Font.BOLD, 14)
        );

        btnConsultations = new JButton("Consultas");
        btnConsultations.setFont(
                new Font("Arial", Font.BOLD, 14)
        );

        btnAssessments = new JButton("Avaliações");
        btnAssessments.setFont(
                new Font("Arial", Font.BOLD, 14)
        );

        btnReports = new JButton("Relatórios");
        btnReports.setFont(
                new Font("Arial", Font.BOLD, 14)
        );

        navPanel.add(btnPatients);
        navPanel.add(btnConsultations);
        navPanel.add(btnAssessments);
        navPanel.add(btnReports);

        add(navPanel, BorderLayout.SOUTH);
    }

    /**
     * Cria um card de indicador e retorna o JLabel do valor.
     */
    private JLabel createIndicatorCard(
            String title, String value, JPanel parent) {

        JPanel card = new JPanel();
        card.setLayout(new BorderLayout(5, 5));
        card.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                Color.GRAY, 1
                        ),
                        BorderFactory.createEmptyBorder(
                                15, 15, 15, 15
                        )
                )
        );

        JLabel lblTitle = new JLabel(
                title, SwingConstants.CENTER
        );
        lblTitle.setFont(
                new Font("Arial", Font.PLAIN, 13)
        );

        JLabel lblValue = new JLabel(
                value, SwingConstants.CENTER
        );
        lblValue.setFont(
                new Font("Arial", Font.BOLD, 36)
        );

        card.add(lblTitle, BorderLayout.NORTH);
        card.add(lblValue, BorderLayout.CENTER);

        parent.add(card);

        return lblValue;
    }

    // === Getters ===

    public JButton getBtnPatients() {
        return btnPatients;
    }

    public JButton getBtnConsultations() {
        return btnConsultations;
    }

    public JButton getBtnAssessments() {
        return btnAssessments;
    }

    public JButton getBtnReports() {
        return btnReports;
    }

    public JButton getBtnLogout() {
        return btnLogout;
    }

    public JLabel getLblTotalPatients() {
        return lblTotalPatients;
    }

    public JLabel getLblTotalConsultations() {
        return lblTotalConsultations;
    }

    public JLabel getLblPending() {
        return lblPending;
    }

    public JLabel getLblCompleted() {
        return lblCompleted;
    }
}