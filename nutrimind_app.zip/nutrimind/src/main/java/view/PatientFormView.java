package view;

import javax.swing.*;
import java.awt.*;

public class PatientFormView extends JDialog {

    private JTextField txtName;
    private JTextField txtCpf;
    private JTextField txtEmail;
    private JTextField txtPhone;
    private JButton btnSave;

    public PatientFormView(JFrame parent) {

        super(parent, true);

        setTitle("Novo Paciente");
        setSize(450, 300);
        setLocationRelativeTo(parent);

        createComponents();

        setVisible(true);
    }

    private void createComponents() {

        JPanel formPanel = new JPanel(
                new GridLayout(5, 2, 10, 10)
        );
        formPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        15, 15, 15, 15
                )
        );

        formPanel.add(new JLabel("Nome *:"));
        txtName = new JTextField();
        formPanel.add(txtName);

        formPanel.add(new JLabel("CPF *:"));
        txtCpf = new JTextField();
        formPanel.add(txtCpf);

        formPanel.add(new JLabel("Email:"));
        txtEmail = new JTextField();
        formPanel.add(txtEmail);

        formPanel.add(new JLabel("Telefone:"));
        txtPhone = new JTextField();
        formPanel.add(txtPhone);

        formPanel.add(new JLabel()); // spacer
        btnSave = new JButton("Salvar");
        btnSave.setFont(
                new Font("Arial", Font.BOLD, 13)
        );
        formPanel.add(btnSave);

        setContentPane(formPanel);
    }

    public JTextField getTxtName() {
        return txtName;
    }

    public JTextField getTxtCpf() {
        return txtCpf;
    }

    public JTextField getTxtEmail() {
        return txtEmail;
    }

    public JTextField getTxtPhone() {
        return txtPhone;
    }

    public JButton getBtnSave() {
        return btnSave;
    }
}