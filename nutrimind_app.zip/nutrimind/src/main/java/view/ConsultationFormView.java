package view;

import model.Patient;

import javax.swing.*;
import java.awt.*;

public class ConsultationFormView extends JDialog {

    private JComboBox<Patient> cbPatients;
    private JTextField txtDate;
    private JComboBox<String> cbStatus;
    private JTextArea txtNotes;
    private JButton btnSave;

    public ConsultationFormView(JFrame parent) {

        super(parent, true);

        setTitle("Nova Consulta");
        setSize(500, 400);
        setLocationRelativeTo(parent);

        createComponents();

        setVisible(true);
    }

    private void createComponents() {

        JPanel formPanel = new JPanel(
                new GridBagLayout()
        );
        formPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        15, 15, 15, 15
                )
        );

        GridBagConstraints gbc =
                new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Paciente
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("Paciente:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        cbPatients = new JComboBox<>();
        formPanel.add(cbPatients, gbc);

        // Data
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;
        formPanel.add(new JLabel("Data (AAAA-MM-DD):"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        txtDate = new JTextField();
        formPanel.add(txtDate, gbc);

        // Status
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0;
        formPanel.add(new JLabel("Status:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        cbStatus = new JComboBox<>(
                new String[]{
                        "PENDING",
                        "COMPLETED",
                        "CANCELLED"
                }
        );
        formPanel.add(cbStatus, gbc);

        // Observações
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0;
        formPanel.add(new JLabel("Observações:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        txtNotes = new JTextArea(5, 20);
        formPanel.add(
                new JScrollPane(txtNotes), gbc
        );

        // Botão Salvar
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        btnSave = new JButton("Salvar");
        btnSave.setFont(
                new Font("Arial", Font.BOLD, 13)
        );
        formPanel.add(btnSave, gbc);

        setContentPane(formPanel);
    }

    public JComboBox<Patient> getCbPatients() {
        return cbPatients;
    }

    public JTextField getTxtDate() {
        return txtDate;
    }

    public JComboBox<String> getCbStatus() {
        return cbStatus;
    }

    public JTextArea getTxtNotes() {
        return txtNotes;
    }

    public JButton getBtnSave() {
        return btnSave;
    }
}