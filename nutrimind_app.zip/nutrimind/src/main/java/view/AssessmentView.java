package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class AssessmentView extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private JButton btnNew;
    private JButton btnEdit;
    private JButton btnDelete;

    public AssessmentView() {

        setTitle("NutriMind - Avaliações Nutricionais");
        setSize(900, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        createComponents();

        setVisible(true);
    }

    private void createComponents() {

        JPanel topPanel = new JPanel(
                new FlowLayout(FlowLayout.LEFT, 10, 10)
        );

        btnNew = new JButton("Nova");
        btnEdit = new JButton("Editar");
        btnDelete = new JButton("Excluir");

        topPanel.add(btnNew);
        topPanel.add(btnEdit);
        topPanel.add(btnDelete);

        add(topPanel, BorderLayout.NORTH);

        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(
                    int row, int column) {
                return false;
            }
        };

        model.addColumn("ID");
        model.addColumn("Paciente");
        model.addColumn("Hábitos Alimentares");
        model.addColumn("Consumo de Água");
        model.addColumn("Atividade Física");
        model.addColumn("Data");

        table = new JTable(model);
        table.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        add(
                new JScrollPane(table),
                BorderLayout.CENTER
        );
    }

    public JTable getTable() {
        return table;
    }

    public DefaultTableModel getModel() {
        return model;
    }

    public JButton getBtnNew() {
        return btnNew;
    }

    public JButton getBtnEdit() {
        return btnEdit;
    }

    public JButton getBtnDelete() {
        return btnDelete;
    }
}
