package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class PatientView extends JFrame {

    private JButton btnNew;
    private JButton btnEdit;
    private JButton btnDelete;
    private JTable table;
    private DefaultTableModel model;

    public PatientView() {

        setTitle("NutriMind - Pacientes");
        setSize(900, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        createComponents();

        setVisible(true);
    }

    private void createComponents() {

        JPanel topPanel = new JPanel(
                new FlowLayout(FlowLayout.LEFT, 10, 10)
        );

        btnNew = new JButton("Novo");
        btnEdit = new JButton("Editar");
        btnDelete = new JButton("Excluir");

        topPanel.add(btnNew);
        topPanel.add(btnEdit);
        topPanel.add(btnDelete);

        add(topPanel, BorderLayout.NORTH);

        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(
                    int row, int column) {
                return false;
            }
        };

        model.addColumn("ID");
        model.addColumn("Nome");
        model.addColumn("CPF");
        model.addColumn("Email");
        model.addColumn("Telefone");

        table = new JTable(model);
        table.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);
    }

    public DefaultTableModel getModel() {
        return model;
    }

    public JButton getBtnNew() {
        return btnNew;
    }

    public JButton getBtnEdit() {
        return btnEdit;
    }

    public JButton getBtnDelete() {
        return btnDelete;
    }

    public JTable getTable() {
        return table;
    }
}