package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class ReportView extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private JButton btnGenerate;
    private JButton btnView;
    private JTextArea txtReportContent;

    public ReportView() {

        setTitle("NutriMind - Relatórios");
        setSize(950, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        createComponents();

        setVisible(true);
    }

    private void createComponents() {

        // Painel superior com botões
        JPanel topPanel = new JPanel(
                new FlowLayout(FlowLayout.LEFT, 10, 10)
        );

        btnGenerate = new JButton(
                "Gerar Resumo da Consulta"
        );
        btnView = new JButton(
                "Visualizar Relatório"
        );

        topPanel.add(btnGenerate);
        topPanel.add(btnView);

        add(topPanel, BorderLayout.NORTH);

        // SplitPane: tabela + área de texto
        JSplitPane splitPane = new JSplitPane(
                JSplitPane.VERTICAL_SPLIT
        );
        splitPane.setDividerLocation(250);

        // Tabela de consultas
        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(
                    int row, int column) {
                return false;
            }
        };

        model.addColumn("ID");
        model.addColumn("Paciente");
        model.addColumn("Nutricionista");
        model.addColumn("Data");
        model.addColumn("Status");
        model.addColumn("Observações");

        table = new JTable(model);
        table.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        splitPane.setTopComponent(
                new JScrollPane(table)
        );

        // Área de visualização do relatório
        txtReportContent = new JTextArea();
        txtReportContent.setEditable(false);
        txtReportContent.setFont(
                new Font("Monospaced", Font.PLAIN, 13)
        );
        txtReportContent.setBorder(
                BorderFactory.createTitledBorder(
                        "Resumo / Relatório"
                )
        );

        splitPane.setBottomComponent(
                new JScrollPane(txtReportContent)
        );

        add(splitPane, BorderLayout.CENTER);
    }

    public JTable getTable() {
        return table;
    }

    public DefaultTableModel getModel() {
        return model;
    }

    public JButton getBtnGenerate() {
        return btnGenerate;
    }

    public JButton getBtnView() {
        return btnView;
    }

    public JTextArea getTxtReportContent() {
        return txtReportContent;
    }
}
