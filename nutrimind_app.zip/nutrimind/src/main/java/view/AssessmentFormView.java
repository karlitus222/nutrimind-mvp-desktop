package view;

import model.Patient;

import javax.swing.*;
import java.awt.*;

public class AssessmentFormView extends JDialog {

    private JComboBox<Patient> cbPatients;
    private JTextArea txtEatingHabits;
    private JTextField txtWaterIntake;
    private JTextField txtPhysicalActivity;
    private JTextArea txtObservations;
    private JButton btnSave;

    public AssessmentFormView(JFrame parent) {

        super(parent, true);

        setTitle("Nova Avaliação Nutricional");
        setSize(550, 500);
        setLocationRelativeTo(parent);

        createComponents();

        setVisible(true);
    }

    private void createComponents() {

        JPanel formPanel = new JPanel(
                new GridBagLayout()
        );
        formPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        15, 15, 15, 15
                )
        );

        GridBagConstraints gbc =
                new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Paciente
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(
                new JLabel("Paciente:"), gbc
        );

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        cbPatients = new JComboBox<>();
        formPanel.add(cbPatients, gbc);

        // Hábitos Alimentares
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;
        formPanel.add(
                new JLabel("Hábitos Alimentares:"), gbc
        );

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.weighty = 0.5;
        gbc.fill = GridBagConstraints.BOTH;
        txtEatingHabits = new JTextArea(3, 20);
        formPanel.add(
                new JScrollPane(txtEatingHabits), gbc
        );

        // Consumo de Água
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(
                new JLabel("Consumo de Água:"), gbc
        );

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        txtWaterIntake = new JTextField();
        formPanel.add(txtWaterIntake, gbc);

        // Atividade Física
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0;
        formPanel.add(
                new JLabel("Atividade Física:"), gbc
        );

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        txtPhysicalActivity = new JTextField();
        formPanel.add(txtPhysicalActivity, gbc);

        // Observações
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.weightx = 0;
        formPanel.add(
                new JLabel("Observações:"), gbc
        );

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.weighty = 0.5;
        gbc.fill = GridBagConstraints.BOTH;
        txtObservations = new JTextArea(3, 20);
        formPanel.add(
                new JScrollPane(txtObservations), gbc
        );

        // Botão Salvar
        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        btnSave = new JButton("Salvar");
        btnSave.setFont(
                new Font("Arial", Font.BOLD, 13)
        );
        formPanel.add(btnSave, gbc);

        setContentPane(formPanel);
    }

    public JComboBox<Patient> getCbPatients() {
        return cbPatients;
    }

    public JTextArea getTxtEatingHabits() {
        return txtEatingHabits;
    }

    public JTextField getTxtWaterIntake() {
        return txtWaterIntake;
    }

    public JTextField getTxtPhysicalActivity() {
        return txtPhysicalActivity;
    }

    public JTextArea getTxtObservations() {
        return txtObservations;
    }

    public JButton getBtnSave() {
        return btnSave;
    }
}
