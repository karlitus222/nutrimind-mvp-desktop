package service.ai;

/**
 * Implementação MOCK do serviço de geração de relatórios.
 * Retorna dados simulados para desenvolvimento.
 */
public class MockReportGenerationService
        implements ReportGenerationService {

    @Override
    public String generateReport(
            int consultationId) {

        return "[MOCK] Relatório simulado para consulta "
                + consultationId
                + ". Geração por IA será implementada futuramente.";
    }
}
