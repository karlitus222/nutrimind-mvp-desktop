package service.ai;

/**
 * Interface para serviço de análise de áudio.
 * Preparada para futura integração com IA.
 */
public interface AudioAnalysisService {

    /**
     * Analisa um arquivo de áudio e retorna
     * a transcrição/análise.
     *
     * @param audioPath Caminho do arquivo de áudio
     * @return Resultado da análise
     */
    String analyzeAudio(String audioPath);
}
