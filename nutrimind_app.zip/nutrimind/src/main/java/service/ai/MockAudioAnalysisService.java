package service.ai;

/**
 * Implementação MOCK do serviço de análise de áudio.
 * Retorna dados simulados para desenvolvimento.
 */
public class MockAudioAnalysisService
        implements AudioAnalysisService {

    @Override
    public String analyzeAudio(String audioPath) {

        return "[MOCK] Transcrição simulada do áudio: "
                + audioPath
                + ". Integração com IA será implementada futuramente.";
    }
}
