package service.ai;

/**
 * Interface para serviço de geração de relatórios com IA.
 * Preparada para futura integração.
 */
public interface ReportGenerationService {

    /**
     * Gera um relatório inteligente para a consulta.
     *
     * @param consultationId ID da consulta
     * @return Relatório gerado
     */
    String generateReport(int consultationId);
}
