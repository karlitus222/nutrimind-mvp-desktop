package connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {

    private static ConnectionFactory instance;

    private static final String URL =
            "jdbc:postgresql://localhost:5432/nutrimind";

    private static final String USER = "postgres";

    private static final String PASSWORD = "022006";

    private ConnectionFactory() {
    }

    public static ConnectionFactory getInstance() {

        if (instance == null) {
            instance = new ConnectionFactory();
        }

        return instance;
    }

    public Connection getConnection() throws SQLException {

        return DriverManager.getConnection(
                URL,
                USER,
                PASSWORD
        );
    }
}