package model;

public class User extends Pessoa {

    private String password;
    private String role;
    private boolean active;

    public User() {
    }

    public User(String name,
                String email,
                String password,
                String role) {

        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
        this.active = true;
    }

    @Override
    public void exibirDados() {
        System.out.println("Usuário: " + getName());
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}