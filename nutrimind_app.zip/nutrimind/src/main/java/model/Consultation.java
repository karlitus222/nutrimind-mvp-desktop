package model;

public class Consultation {

    private int id;
    private int patientId;
    private int nutritionistId;
    private String date;
    private String notes;
    private String status;

    // Campos auxiliares para exibição com JOIN
    private String patientName;
    private String nutritionistCrn;

    public Consultation() {
    }

    public Consultation(
            int id,
            int patientId,
            int nutritionistId,
            String date,
            String notes,
            String status) {

        this.id = id;
        this.patientId = patientId;
        this.nutritionistId = nutritionistId;
        this.date = date;
        this.notes = notes;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public int getNutritionistId() {
        return nutritionistId;
    }

    public void setNutritionistId(int nutritionistId) {
        this.nutritionistId = nutritionistId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getNutritionistCrn() {
        return nutritionistCrn;
    }

    public void setNutritionistCrn(String nutritionistCrn) {
        this.nutritionistCrn = nutritionistCrn;
    }
}