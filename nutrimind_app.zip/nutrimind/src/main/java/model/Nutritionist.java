package model;

public class Nutritionist {

    private int id;

    private User user;

    private String crn;

    public Nutritionist() {
    }

    public Nutritionist(User user, String crn) {
        this.user = user;
        this.crn = crn;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getCrn() {
        return crn;
    }

    public void setCrn(String crn) {
        this.crn = crn;
    }
}