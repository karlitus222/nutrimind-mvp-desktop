package model;

public class ConsultationReport {

    private int id;
    private int consultationId;
    private String summary;
    private String alerts;
    private boolean reviewed;
    private boolean generatedByAI;

    public ConsultationReport() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getConsultationId() {
        return consultationId;
    }

    public void setConsultationId(int consultationId) {
        this.consultationId = consultationId;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getAlerts() {
        return alerts;
    }

    public void setAlerts(String alerts) {
        this.alerts = alerts;
    }

    public boolean isReviewed() {
        return reviewed;
    }

    public void setReviewed(boolean reviewed) {
        this.reviewed = reviewed;
    }

    public boolean isGeneratedByAI() {
        return generatedByAI;
    }

    public void setGeneratedByAI(boolean generatedByAI) {
        this.generatedByAI = generatedByAI;
    }
}