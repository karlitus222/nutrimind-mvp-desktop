# NutriMind

Sistema desktop para nutricionistas desenvolvido em Java Swing com PostgreSQL.

## Estrutura do Projeto

```
nutrimind/
├── src/main/java/
│   ├── connection/
│   │   └── ConnectionFactory.java      # Singleton para conexão PostgreSQL
│   ├── controller/
│   │   ├── LoginController.java        # Autenticação de usuários
│   │   ├── DashboardController.java    # Dashboard com indicadores
│   │   ├── PatientController.java      # CRUD de pacientes
│   │   ├── ConsultationController.java # CRUD de consultas
│   │   ├── AssessmentController.java   # CRUD de avaliações nutricionais
│   │   └── ReportController.java       # Geração e visualização de relatórios
│   ├── dao/
│   │   ├── GenericDAO.java             # Interface genérica CRUD
│   │   ├── UserDAO.java               # Autenticação
│   │   ├── DashboardDAO.java          # Indicadores do dashboard
│   │   ├── PatientDAO.java            # CRUD pacientes
│   │   ├── ConsultationDAO.java       # CRUD consultas (com JOIN)
│   │   ├── NutritionalAssessmentDAO.java # CRUD avaliações
│   │   └── ConsultationReportDAO.java # CRUD relatórios
│   ├── model/
│   │   ├── Pessoa.java                # Classe abstrata base
│   │   ├── User.java                  # Modelo de usuário
│   │   ├── Nutritionist.java          # Modelo de nutricionista
│   │   ├── Patient.java               # Modelo de paciente
│   │   ├── Consultation.java          # Modelo de consulta
│   │   ├── NutritionalAssessment.java # Modelo de avaliação
│   │   └── ConsultationReport.java    # Modelo de relatório
│   ├── view/
│   │   ├── LoginView.java             # Tela de login
│   │   ├── DashboardView.java         # Dashboard com indicadores
│   │   ├── PatientView.java           # Lista de pacientes
│   │   ├── PatientFormView.java       # Formulário paciente
│   │   ├── ConsultationView.java      # Lista de consultas
│   │   ├── ConsultationFormView.java  # Formulário consulta
│   │   ├── AssessmentView.java        # Lista de avaliações
│   │   ├── AssessmentFormView.java    # Formulário avaliação
│   │   └── ReportView.java           # Tela de relatórios
│   ├── service/ai/
│   │   ├── AudioAnalysisService.java           # Interface para IA (futura)
│   │   ├── ReportGenerationService.java        # Interface para IA (futura)
│   │   ├── MockAudioAnalysisService.java       # Mock de análise de áudio
│   │   └── MockReportGenerationService.java    # Mock de geração de relatório
│   ├── main/
│   │   └── Main.java                  # Classe principal
│   └── util/                          # Utilitários (extensível)
├── database_update.sql                # Scripts SQL para o banco
├── pom.xml                            # Configuração Maven
├── README.md                          # Este arquivo
└── CHANGES.md                         # Histórico de alterações
```

## Pré-requisitos

- **Java 21** ou superior
- **Maven 3.6+**
- **PostgreSQL 12+**

## Configuração do Banco de Dados

1. Crie o banco de dados no PostgreSQL:

```sql
CREATE DATABASE nutrimind;
```

2. Execute o script `database_update.sql` no banco `nutrimind`:

```bash
psql -U postgres -d nutrimind -f database_update.sql
```

3. Verifique as credenciais de conexão em `ConnectionFactory.java`:
   - **URL**: `jdbc:postgresql://localhost:5432/nutrimind`
   - **Usuário**: `postgres`
   - **Senha**: `022006`

## Como Executar

### Via Maven

```bash
mvn compile exec:java -Dexec.mainClass="main.Main"
```

### Via NetBeans

1. Abra o projeto no NetBeans
2. Execute a classe `main.Main`

## Credenciais de Login

| Email | Senha |
|-------|-------|
| admin@nutrimind.com | admin123 |

## Funcionalidades Implementadas

### 1. Login
- Autenticação via email e senha
- Validação no PostgreSQL
- Bloqueio de acesso sem autenticação
- Mensagens de erro amigáveis

### 2. Dashboard
- Total de Pacientes
- Total de Consultas
- Consultas Pendentes
- Consultas Concluídas
- Navegação para todos os módulos
- Botão de logout

### 3. CRUD de Pacientes
- Cadastrar, listar, editar, excluir
- Validação de Nome e CPF obrigatórios
- Atualização automática da tabela

### 4. CRUD de Consultas
- Cadastrar, listar, editar, excluir
- ComboBox com pacientes do banco
- Exibição de nome do paciente (JOIN)
- Exibição de CRN do nutricionista (JOIN)

### 5. Avaliações Nutricionais
- CRUD completo
- Campos: hábitos alimentares, consumo de água, atividade física, observações
- Relacionado com paciente via ComboBox

### 6. Relatórios
- Visualização de consultas com observações
- Geração de resumo simples (sem IA)
- Inclusão de avaliações nutricionais no resumo
- Persistência de relatórios no banco

### 7. Preparação para IA
- Interfaces prontas: `AudioAnalysisService`, `ReportGenerationService`
- Implementações Mock disponíveis
- Pacote `service.ai` preparado para integração futura

## Padrões Utilizados

- **MVC** (Model-View-Controller)
- **DAO** (Data Access Object)
- **Singleton** (ConnectionFactory)
- **SOLID**
- **GenericDAO** (Interface genérica)
