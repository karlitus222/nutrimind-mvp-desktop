# CHANGES.md - Histórico de Alterações do NutriMind

## Versão 1.0.0 - MVP Acadêmico

### Arquivos Modificados

#### `model/Consultation.java`
- **Removido**: Método `save()` que estava no model (violação MVC) - pertence ao DAO
- **Removido**: Import desnecessário `connection.ConnectionFactory` e `java.sql.Connection`
- **Adicionado**: Campos auxiliares `patientName` e `nutritionistCrn` para exibição com JOIN
- **Adicionado**: Getters e setters para os novos campos

#### `model/ConsultationReport.java`
- **Reescrito**: Implementados todos os getters e setters
- **Alterado**: Campo `consultation` (objeto) substituído por `consultationId` (int) para consistência com padrão DAO

#### `model/NutritionalAssessment.java`
- **Reescrito**: Campos atualizados conforme requisitos (eatingHabits, waterIntake, physicalActivity, observations, createdAt)
- **Adicionado**: Campo auxiliar `patientName` para exibição
- **Implementados**: Todos os getters e setters

#### `dao/ConsultationDAO.java`
- **Implementado**: Método `save()` (estava vazio)
- **Implementado**: Método `update()` (estava vazio)
- **Implementado**: Método `delete()` (estava vazio)
- **Implementado**: Método `findById()` (retornava null)
- **Adicionado**: Método `findAllWithJoin()` com JOIN entre consultation, patients e nutritionists
- **Corrigido**: Import duplicado `java.util.List`

#### `dao/PatientDAO.java`
- **Corrigido**: Import duplicado `java.util.List` (linha 10)

#### `controller/PatientController.java`
- **Adicionado**: Funcionalidade de edição completa
- **Adicionado**: Validação de Nome obrigatório
- **Adicionado**: Validação de CPF obrigatório
- **Adicionado**: Mensagens de sucesso após operações
- **Melhorado**: Mensagens de erro mais amigáveis

#### `controller/ConsultationController.java`
- **Reescrito**: Utiliza `findAllWithJoin()` para exibir nomes
- **Adicionado**: Funcionalidade de edição
- **Adicionado**: Funcionalidade de exclusão
- **Adicionado**: Validações de campos obrigatórios
- **Alterado**: Recebe `nutritionistId` do login (não mais hardcoded)

#### `view/DashboardView.java`
- **Reescrito**: Adicionados painéis de indicadores (Total Pacientes, Total Consultas, Pendentes, Concluídas)
- **Corrigido**: Bug do `btnPatients` criado 2 vezes (listener perdido)
- **Adicionado**: Botão de logout
- **Melhorado**: Layout com BorderLayout organizado

#### `view/PatientView.java`
- **Melhorado**: Tabela não editável diretamente
- **Melhorado**: Seleção única na tabela

#### `view/PatientFormView.java`
- **Melhorado**: Labels com indicação de campo obrigatório (*)
- **Melhorado**: Layout com borders e espaçamento

#### `view/ConsultationView.java`
- **Melhorado**: Tabela não editável diretamente
- **Melhorado**: Seleção única na tabela

#### `view/ConsultationFormView.java`
- **Melhorado**: Layout com GridBagLayout para melhor organização
- **Melhorado**: Label de data com formato esperado

#### `main/Main.java`
- **Alterado**: Inicia com `LoginController` ao invés de `DashboardView`
- **Adicionado**: `SwingUtilities.invokeLater()` para thread-safety

### Arquivos Criados

#### DAO
- `dao/UserDAO.java` - Autenticação de usuários e busca de nutricionista
- `dao/DashboardDAO.java` - Indicadores do dashboard (contadores)
- `dao/NutritionalAssessmentDAO.java` - CRUD completo com JOIN
- `dao/ConsultationReportDAO.java` - CRUD completo com busca por consulta

#### Controller
- `controller/LoginController.java` - Autenticação com validações
- `controller/DashboardController.java` - Dashboard com indicadores e navegação
- `controller/AssessmentController.java` - CRUD de avaliações nutricionais
- `controller/ReportController.java` - Geração e visualização de relatórios

#### View
- `view/LoginView.java` - Tela de login com email e senha
- `view/AssessmentView.java` - Lista de avaliações nutricionais
- `view/AssessmentFormView.java` - Formulário de avaliação nutricional
- `view/ReportView.java` - Tela de relatórios com split pane

#### Serviço de IA (Preparação)
- `service/ai/AudioAnalysisService.java` - Interface para análise de áudio
- `service/ai/ReportGenerationService.java` - Interface para geração de relatórios
- `service/ai/MockAudioAnalysisService.java` - Implementação mock
- `service/ai/MockReportGenerationService.java` - Implementação mock

#### Banco de Dados
- `database_update.sql` - Script SQL completo

#### Documentação
- `README.md` - Documentação do projeto
- `CHANGES.md` - Este arquivo

### Arquivos Removidos/Obsoletos
- `controller/dao.java` - Classe vazia gerada automaticamente pelo NetBeans (mantida mas sem uso)

### Scripts SQL Necessários
- Executar `database_update.sql` no banco PostgreSQL `nutrimind`
- Cria tabelas: `users`, `nutritionists`, `nutritional_assessments`, `consultation_reports`
- Cria índices de performance
- Insere usuário padrão: `admin@nutrimind.com` / `admin123`

### Passos Manuais Obrigatórios
1. Verificar se o banco `nutrimind` existe no PostgreSQL
2. Executar `database_update.sql`
3. Verificar credenciais em `ConnectionFactory.java` (URL, user, password)
